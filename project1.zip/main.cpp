#include <iostream>
#include <vector>
#include "Game.hpp"

int main() {
    // Initialize the game
    Game monopolyGame;

    // Add players
    int numPlayers;
    std::cout << "Enter number of players (2-8): ";
    std::cin >> numPlayers;

    // Simple input validation
    if (numPlayers < 2 || numPlayers > 8) {
        std::cerr << "Invalid number of players. Please restart the game." << std::endl;
        return 1;
    }
    std::cout << "Want to use default default names(Player1, Player2, ...)? (y/n)" << std::endl;
    std::string input;
    std::cin >> input;
    if(input == "y" || input == "Y"){
        for (int i = 0; i < numPlayers; ++i) {
            std::string playerName = "Player" + std::to_string(i);
            monopolyGame.addPlayer(Player(playerName));
        }
    } else if(input == "n" || input == "N"){
        for (int i = 0; i < numPlayers; ++i) {
            std::string playerName;
            std::cout << "Enter name for player " << (i + 1) << ": ";
            std::cin >> playerName;
            monopolyGame.addPlayer(Player(playerName));
        }
    } else {
        std::cerr << "Invalid input. Please restart the game." << std::endl;
        return 1;
    }

    // Main game loop
    while (!monopolyGame.isGameOver()) {
        for (auto& player : monopolyGame.getPlayers()) {
            std::cout << player.getName() << "'s turn. Press Enter to roll the dice...";
            std::cin.ignore(); // Wait for user input
            monopolyGame.playerTurn(player);
            if (monopolyGame.isGameOver()) {
                break; // Exit if game is over
            }
        }
    }

    // Determine and display the winner
    Player winner = monopolyGame.getWinner();
    std::cout << winner.getName() << " wins the game!" << std::endl;

    return 0;
}
