#include "Player.hpp"
#include "Train.hpp"
Player::Player(const std::string& name)
    : name(name), money(1500), position(0), trainsOwned(0),outOfJailCard(0), isBankrupt(false) {}

void Player::pay(int amount) {
    if(money - amount < 0){
        std::cout << getName() << " has declared bankruptcy" << std::endl;
        isBankrupt = true;
    }
    money -= amount;
}

void Player::receive(int amount) {
    money += amount;
}

void Player::setPosition(int newPosition) {
    position = newPosition;
}

int Player::getPosition() const {
    return position;
}

const std::string& Player::getName() const {
    return name;
}

int Player::getMoney() const {
    return money;
}

void Player::addProperty(Slot* property) {
    if (property) {
        ownedProperties.push_back(property);
        if (dynamic_cast<Train*>(property)) {
            trainsOwned++;
        }
    }
}

int Player::getTrainCount() const {
    return trainsOwned;
}

void Player::IncrementTrainsOwned(){
    trainsOwned++;
}

std::vector<Slot*> Player::getOwnedProperties(){
    return ownedProperties;
}

void Player::addGetOutOfJailCard(){
    outOfJailCard++;
}

bool Player::removeGetOutOfJailCard(){
    if(outOfJailCard > 0){
        outOfJailCard--;
        return true;
    }
    return false;
}