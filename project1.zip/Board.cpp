#include <iostream>
#include "Board.hpp"
#include "SpecialSlot.hpp"
#include "Train.hpp"
// Constructor to initialize the board
Board::Board(): jailIndex(0) {
    initializeColorGroups();
}

// Destructor to clean up dynamically allocated slots
Board::~Board() {
    for (auto slot : slots) {
        delete slot;
    }
}

// Add a new slot to the board
void Board::addSlot(Slot* slot) {
    slots.push_back(slot);
}

// Get a slot by index
Slot* Board::getSlot(int index) const {
    if (index >= 0 && (unsigned int)index < slots.size()) {
        return slots[index];
    }
    return nullptr; // Return nullptr for invalid index
}

// Get the total number of slots
int Board::getNumberOfSlots() const {
    return slots.size();
}

// Initialize color groups and add streets to them
void Board::initializeColorGroups() {
    // Define color groups and their respective streets
    colorGroups.push_back({"Brown", {}});
    colorGroups.push_back({"Light Blue", {}});
    colorGroups.push_back({"Pink", {}});
    colorGroups.push_back({"Orange", {}});
    colorGroups.push_back({"Red", {}});
    colorGroups.push_back({"Yellow", {}});
    colorGroups.push_back({"Green", {}});
    colorGroups.push_back({"Dark Blue", {}});
}

int Board::getJailIndex(){
    return jailIndex;
}

int Board::getIllinoisAveIndex(){
    return IllinoisAveIndex;
}
int Board::getCharlesPlaceIndex(){
    return CharlesPlaceIndex;
}


int Board::getNearestUtilityIndex(int startPosition){
    for(int i = startPosition+1; i != startPosition; i = (i + 1 ) % slots.size()){
        if(slots[i]->getIsUtility()){
            return i;
        }
    }
    std::cerr << "No ulitily found, probably an error, check the code." << std::endl;
    return 0;
}

int Board::getNearestRailroadIndex(int startPosition){
    for(int i = startPosition+1; i != startPosition; i = (i + 1 ) % slots.size()){
        if(slots[i]->getIsRailroad()){
            return i;
        }
    }
    std::cerr << "No railroad found, probably an error, check the code." << std::endl;
    return 0;
}

std::vector<ColorGroup>& Board::getColorGroups(){
    return colorGroups;
}